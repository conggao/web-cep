CREATE VIEW `view_student_base_info` AS
  SELECT
    `uc`.`studentId`  AS `id`,
    `io1`.`ioTime`    AS `inTime`,
    `io2`.`ioTime`    AS `outTime`,
    `f1`.`food`       AS `breakfast`,
    `f2`.`food`       AS `lunch`,
    `h`.`temperature` AS `temperature`,
    `h`.`disease`     AS `disease`
  FROM ((((((`cep_io`.`io_base_info` `io1`
    JOIN `cep_io`.`io_base_info` `io2`) JOIN `cep_master`.`food_base_info` `f1`) JOIN
    `cep_master`.`food_base_info` `f2`) JOIN `cep_master`.`health_base_info` `h`) JOIN
    `cep_master`.`user_child_info` `uc`) JOIN `cep_master`.`user_student_info` `us`)
  WHERE ((`io1`.`studentId` = `io2`.`studentId`) AND (`io1`.`studentId` = `uc`.`studentId`) AND
         (`uc`.`userId` = `us`.`userId`) AND (`us`.`classId` = `f1`.`classId`) AND (`f1`.`classId` = `f2`.`classId`) AND
         (`io1`.`type` = 0) AND (`io2`.`type` = 1) AND (`f1`.`type` = 0) AND (`f2`.`type` = 1))