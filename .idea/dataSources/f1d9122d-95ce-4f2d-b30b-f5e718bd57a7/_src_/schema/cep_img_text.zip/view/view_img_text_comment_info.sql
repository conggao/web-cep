CREATE VIEW `view_img_text_comment_info` AS
  SELECT
    `cep_img_text`.`img_text_comment_info`.`id`           AS `id`,
    `cep_img_text`.`img_text_comment_info`.`imgTextId`    AS `imgTextId`,
    `cep_img_text`.`img_text_comment_info`.`content`      AS `content`,
    `cep_img_text`.`img_text_comment_info`.`createUserId` AS `createUserId`,
    `cep_img_text`.`img_text_comment_info`.`createTime`   AS `createTime`,
    `cep_img_text`.`img_text_comment_info`.`isDel`        AS `isDel`,
    `cep_master`.`user_base_info`.`userName`              AS `createUserName`,
    `cep_master`.`user_base_info`.`realName`              AS `createUserRealName`,
    `view_upload_file_info`.`url`                         AS `createUserHeadUrl`
  FROM ((`cep_img_text`.`img_text_comment_info`
    JOIN `cep_master`.`user_base_info`) JOIN `cep_file`.`view_upload_file_info`)
  WHERE ((`cep_img_text`.`img_text_comment_info`.`createUserId` = `cep_master`.`user_base_info`.`userId`) AND
         (`cep_master`.`user_base_info`.`headPicId` = `view_upload_file_info`.`id`))