CREATE VIEW `view_teacher_student_info` AS
  SELECT
    `teacher`.`userId` AS `teacherId`,
    `student`.`userId` AS `studentId`
  FROM `cep_master`.`user_teacher_info` `teacher`
    JOIN `cep_master`.`user_student_info` `student`
  WHERE (`student`.`classId` = `teacher`.`classId`)