CREATE VIEW `view_user_simple_info` AS
  SELECT
    `fsc_master`.`user_base_info`.`userId`      AS `userId`,
    `fsc_master`.`user_base_info`.`userName`    AS `userName`,
    `fsc_master`.`user_base_info`.`mobilePhone` AS `mobilePhone`,
    `fsc_master`.`user_base_info`.`role`        AS `role`,
    `fsc_master`.`user_base_info`.`sex`         AS `sex`,
    `fsc_master`.`user_base_info`.`nickName`    AS `nickName`,
    `fsc_master`.`user_base_info`.`realName`    AS `realName`,
    `fsc_master`.`user_base_info`.`birthday`    AS `birthday`,
    `fsc_master`.`user_im_info`.`imAccount`     AS `imAccount`,
    `view_upload_file_info`.`url`               AS `headUrl`
  FROM ((`fsc_master`.`user_base_info`
    JOIN `fsc_master`.`user_im_info`) JOIN `fsc_file`.`view_upload_file_info`)
  WHERE ((`fsc_master`.`user_base_info`.`headPicId` = `view_upload_file_info`.`id`) AND
         (`fsc_master`.`user_base_info`.`userId` = `fsc_master`.`user_im_info`.`userId`))