CREATE VIEW `view_img_text_base_info` AS
  SELECT
    `cep_img_text`.`img_text_base_info`.`id`             AS `id`,
    `cep_img_text`.`img_text_base_info`.`schoolId`       AS `schoolId`,
    `cep_img_text`.`img_text_base_info`.`type`           AS `type`,
    `cep_img_text`.`img_text_type`.`name`                AS `typeName`,
    `cep_img_text`.`img_text_base_info`.`title`          AS `title`,
    `cep_img_text`.`img_text_base_info`.`content`        AS `content`,
    `cep_img_text`.`img_text_base_info`.`createUserId`   AS `createUserId`,
    `cep_img_text`.`img_text_base_info`.`createTime`     AS `createTime`,
    `cep_img_text`.`img_text_base_info`.`lastUpdateTime` AS `lastUpdateTime`,
    `cep_img_text`.`img_text_base_info`.`praiseNum`      AS `praiseNum`,
    `cep_img_text`.`img_text_base_info`.`commentNum`     AS `commentNum`,
    `cep_img_text`.`img_text_base_info`.`isDel`          AS `isDel`,
    `cep_master`.`user_base_info`.`userName`             AS `createUserName`,
    `cep_master`.`user_base_info`.`realName`             AS `createUserRealName`,
    `view_upload_file_info`.`url`                        AS `createUserHeadUrl`,
    `cep_img_text`.`img_text_base_info`.`labelId`        AS `labelId`
  FROM (((`cep_img_text`.`img_text_base_info`
    JOIN `cep_img_text`.`img_text_type`) JOIN `cep_master`.`user_base_info`) JOIN `cep_file`.`view_upload_file_info`)
  WHERE ((`cep_img_text`.`img_text_base_info`.`createUserId` = `cep_master`.`user_base_info`.`userId`) AND
         (`cep_img_text`.`img_text_base_info`.`type` = `cep_img_text`.`img_text_type`.`id`) AND
         (`cep_master`.`user_base_info`.`headPicId` = `view_upload_file_info`.`id`))