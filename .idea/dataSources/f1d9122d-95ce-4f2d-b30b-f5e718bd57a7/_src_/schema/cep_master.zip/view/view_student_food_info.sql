CREATE VIEW `view_student_food_info` AS
  SELECT
    `f1`.`classId`    AS `id`,
    `f1`.`food`       AS `breakfast`,
    `f2`.`food`       AS `lunch`,
    `f1`.`createTime` AS `createTime`,
    `f1`.`foodTime`   AS `foodTime`
  FROM (`cep_master`.`food_base_info` `f1`
    JOIN `cep_master`.`food_base_info` `f2`)
  WHERE ((`f1`.`type` = 0) AND (`f2`.`type` = 1) AND (`f1`.`classId` = `f2`.`classId`))