CREATE VIEW `view_sys_privilege_desc` AS
  SELECT
    `cep_master`.`sys_privilege_desc`.`id`            AS `id`,
    `cep_master`.`sys_privilege_desc`.`sysId`         AS `sysId`,
    `cep_master`.`sys_id_desc`.`name`                 AS `sysName`,
    `cep_master`.`sys_privilege_desc`.`privilegeDesc` AS `privilegeDesc`
  FROM (`cep_master`.`sys_privilege_desc`
    JOIN `cep_master`.`sys_id_desc`)
  WHERE (`cep_master`.`sys_privilege_desc`.`sysId` = `cep_master`.`sys_id_desc`.`id`)