CREATE VIEW `view_img_text_read_user_info` AS
  SELECT
    `student`.`userId`    AS `studentId`,
    `imgText`.`imgTextId` AS `imgTextId`
  FROM (`cep_img_text`.`img_text_class_info` `imgText`
    JOIN `cep_master`.`user_student_info` `student`)
  WHERE (`imgText`.`classId` = `student`.`classId`)