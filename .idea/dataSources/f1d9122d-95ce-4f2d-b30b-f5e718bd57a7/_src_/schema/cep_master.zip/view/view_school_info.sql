CREATE VIEW `view_school_info` AS
  SELECT
    `fsc_master`.`school_info`.`id`           AS `id`,
    `fsc_master`.`school_info`.`name`         AS `name`,
    `fsc_master`.`school_info`.`addrCountyId` AS `addrCountyId`,
    `fsc_master`.`school_info`.`addrDetail`   AS `addrDetail`,
    `fsc_area`.`area_county`.`name`           AS `countyName`,
    `fsc_area`.`area_city`.`name`             AS `cityName`,
    `fsc_area`.`area_province`.`name`         AS `provinceName`
  FROM (((`fsc_master`.`school_info`
    JOIN `fsc_area`.`area_county`) JOIN `fsc_area`.`area_city`) JOIN `fsc_area`.`area_province`)
  WHERE ((`fsc_master`.`school_info`.`addrCountyId` = `fsc_area`.`area_county`.`id`) AND
         (`fsc_master`.`school_info`.`addrCityId` = `fsc_area`.`area_city`.`id`) AND
         (`fsc_master`.`school_info`.`addrProvinceId` = `fsc_area`.`area_province`.`id`))