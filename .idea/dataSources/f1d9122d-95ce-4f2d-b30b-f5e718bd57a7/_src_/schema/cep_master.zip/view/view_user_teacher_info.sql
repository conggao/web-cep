CREATE VIEW `view_user_teacher_info` AS
  SELECT
    `cep_master`.`user_teacher_info`.`id`       AS `id`,
    `cep_master`.`user_teacher_info`.`userId`   AS `userId`,
    `cep_master`.`user_teacher_info`.`classId`  AS `classId`,
    `cep_master`.`class_base_info`.`schoolId`   AS `schoolId`,
    `cep_master`.`school_info`.`name`           AS `schoolName`,
    `cep_master`.`class_base_info`.`gradeNo`    AS `gradeNo`,
    `cep_master`.`grade_number_info`.`name`     AS `gradeName`,
    `cep_master`.`class_base_info`.`classNo`    AS `classNo`,
    `cep_master`.`user_teacher_info`.`courseId` AS `courseId`,
    `cep_master`.`course_info`.`name`           AS `courseName`,
    `cep_master`.`class_base_info`.`inviteCode` AS `inviteCode`
  FROM ((((`cep_master`.`user_teacher_info`
    JOIN `cep_master`.`class_base_info`) JOIN `cep_master`.`school_info`) JOIN `cep_master`.`course_info`) JOIN
    `cep_master`.`grade_number_info`)
  WHERE ((`cep_master`.`user_teacher_info`.`classId` = `cep_master`.`class_base_info`.`id`) AND
         (`cep_master`.`class_base_info`.`schoolId` = `cep_master`.`school_info`.`id`) AND
         (`cep_master`.`user_teacher_info`.`courseId` = `cep_master`.`course_info`.`id`) AND
         (`cep_master`.`class_base_info`.`gradeNo` = `cep_master`.`grade_number_info`.`id`))