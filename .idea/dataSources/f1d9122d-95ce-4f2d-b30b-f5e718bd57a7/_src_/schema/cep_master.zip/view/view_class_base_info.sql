CREATE VIEW `view_class_base_info` AS
  SELECT
    `cep_master`.`class_base_info`.`id`         AS `id`,
    `cep_master`.`class_base_info`.`schoolId`   AS `schoolId`,
    `cep_master`.`class_base_info`.`gradeNo`    AS `gradeNo`,
    `cep_master`.`class_base_info`.`classNo`    AS `classNo`,
    `cep_master`.`class_base_info`.`inviteCode` AS `inviteCode`,
    `cep_master`.`class_base_info`.`isDel`      AS `isDel`,
    `cep_master`.`class_base_info`.`updateTime` AS `updateTime`,
    `cep_master`.`grade_number_info`.`name`     AS `gradeName`
  FROM (`cep_master`.`class_base_info`
    JOIN `cep_master`.`grade_number_info`)
  WHERE (`cep_master`.`class_base_info`.`gradeNo` = `cep_master`.`grade_number_info`.`id`)