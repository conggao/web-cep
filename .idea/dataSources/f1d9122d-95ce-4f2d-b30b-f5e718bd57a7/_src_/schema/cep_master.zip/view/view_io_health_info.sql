CREATE VIEW `view_io_health_info` AS
  SELECT
    `u`.`studentId`    AS `id`,
    `io1`.`showDate`   AS `showDate`,
    `io1`.`ioTime`     AS `inTime`,
    `io2`.`ioTime`     AS `outTime`,
    `io1`.`createTime` AS `createTime`,
    `h`.`temperature`  AS `temperature`,
    `h`.`disease`      AS `disease`
  FROM (((`cep_io`.`io_base_info` `io1`
    JOIN `cep_io`.`io_base_info` `io2`) JOIN `cep_master`.`health_base_info` `h`) JOIN
    `cep_master`.`user_child_info` `u`)
  WHERE ((`io1`.`userId` = `io2`.`userId`) AND (`io1`.`userId` = `u`.`userId`) AND (`u`.`userId` = `h`.`userId`) AND
         (`io1`.`type` = 0) AND (`io2`.`type` = 1))