CREATE VIEW `view_user_base_info` AS
  SELECT
    `fsc_master`.`user_base_info`.`userId`      AS `userId`,
    `fsc_master`.`user_base_info`.`userName`    AS `userName`,
    `fsc_master`.`user_base_info`.`mobilePhone` AS `mobilePhone`,
    `fsc_master`.`user_base_info`.`email`       AS `email`,
    `fsc_master`.`user_base_info`.`sex`         AS `sex`,
    `fsc_master`.`user_base_info`.`role`        AS `role`,
    `fsc_master`.`user_base_info`.`nickName`    AS `nickName`,
    `fsc_master`.`user_base_info`.`realName`    AS `realName`,
    `fsc_master`.`user_base_info`.`headPicId`   AS `headPicId`,
    `fsc_master`.`user_base_info`.`birthday`    AS `birthday`,
    `fsc_master`.`user_base_info`.`regFlag`     AS `regFlag`,
    `fsc_master`.`user_base_info`.`regTime`     AS `regTime`,
    `fsc_master`.`user_base_info`.`updateTime`  AS `updateTime`,
    `view_upload_file_info`.`url`               AS `headUrl`
  FROM (`fsc_master`.`user_base_info`
    JOIN `fsc_file`.`view_upload_file_info`)
  WHERE (`fsc_master`.`user_base_info`.`headPicId` = `view_upload_file_info`.`id`)