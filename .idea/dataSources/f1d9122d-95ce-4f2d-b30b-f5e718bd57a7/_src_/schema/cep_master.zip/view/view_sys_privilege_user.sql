CREATE VIEW `view_sys_privilege_user` AS
  SELECT
    `cep_master`.`sys_privilege_user`.`id`          AS `id`,
    `cep_master`.`sys_privilege_user`.`privilegeId` AS `privilegeId`,
    `cep_master`.`sys_privilege_user`.`schoolId`    AS `schoolId`,
    `cep_master`.`sys_privilege_user`.`userId`      AS `userId`,
    `cep_master`.`user_base_info`.`realName`        AS `realName`
  FROM (`cep_master`.`user_base_info`
    JOIN `cep_master`.`sys_privilege_user`)
  WHERE (`cep_master`.`sys_privilege_user`.`userId` = `cep_master`.`user_base_info`.`userId`)