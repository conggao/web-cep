CREATE VIEW `view_img_text_file_info` AS
  SELECT
    `cep_img_text`.`img_text_file_info`.`id`        AS `id`,
    `cep_img_text`.`img_text_file_info`.`imgTextId` AS `imgTextId`,
    `cep_img_text`.`img_text_file_info`.`fileId`    AS `fileId`,
    `view_upload_file_info`.`name`                  AS `fileName`,
    `view_upload_file_info`.`url`                   AS `fileUrl`
  FROM (`cep_img_text`.`img_text_file_info`
    JOIN `cep_file`.`view_upload_file_info`)
  WHERE (`cep_img_text`.`img_text_file_info`.`fileId` = `view_upload_file_info`.`id`)