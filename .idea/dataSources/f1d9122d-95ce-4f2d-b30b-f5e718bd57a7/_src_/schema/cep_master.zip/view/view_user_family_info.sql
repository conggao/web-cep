CREATE VIEW `view_user_family_info` AS
  SELECT
    `cep_master`.`user_family_info`.`userId`           AS `userId`,
    `cep_master`.`user_family_info`.`familyId`         AS `familyId`,
    `cep_master`.`user_family_info`.`familyRoleTypeId` AS `familyRoleTypeId`,
    `cep_master`.`family_role_type`.`name`             AS `familyRoleTypeName`
  FROM (`cep_master`.`user_family_info`
    JOIN `cep_master`.`family_role_type`)
  WHERE (`cep_master`.`user_family_info`.`familyRoleTypeId` = `cep_master`.`family_role_type`.`id`)