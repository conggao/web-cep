CREATE VIEW `view_img_text_user_info` AS
  SELECT
    `view_img_text_base_info`.`id`                 AS `id`,
    `view_img_text_base_info`.`schoolId`           AS `schoolId`,
    `view_img_text_base_info`.`type`               AS `type`,
    `view_img_text_base_info`.`typeName`           AS `typeName`,
    `view_img_text_base_info`.`title`              AS `title`,
    `view_img_text_base_info`.`content`            AS `content`,
    `view_img_text_base_info`.`createUserId`       AS `createUserId`,
    `view_img_text_base_info`.`createTime`         AS `createTime`,
    `view_img_text_base_info`.`lastUpdateTime`     AS `lastUpdateTime`,
    `view_img_text_base_info`.`praiseNum`          AS `praiseNum`,
    `view_img_text_base_info`.`commentNum`         AS `commentNum`,
    `view_img_text_base_info`.`isDel`              AS `isDel`,
    `view_img_text_base_info`.`createUserName`     AS `createUserName`,
    `view_img_text_base_info`.`createUserRealName` AS `createUserRealName`,
    `view_img_text_base_info`.`createUserHeadUrl`  AS `createUserHeadUrl`,
    `view_img_text_base_info`.`labelId`            AS `labelId`
  FROM (`cep_img_text`.`view_img_text_base_info`
    JOIN `cep_img_text`.`img_text_user_info`)
  WHERE (`view_img_text_base_info`.`id` = `cep_img_text`.`img_text_user_info`.`imgTextId`)